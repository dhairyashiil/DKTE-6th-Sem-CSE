
<?php

session_start();
$conn = mysqli_connect("localhost","root","","Form");
    if(!$conn)
    {
        die("Connection failed: ".mysqli_connect_error());
    }
$EmpName=$_SESSION['EmpName'];
$EmpNumber = $_SESSION['EmpNumber'];
$Password=$_SESSION['Password'];
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="style.css" type="text/css">
    <title>Your Profile</title>
</head>
<body>
    <div><h1><?php echo "Hello ".$EmpName." You have Successfully Logged in!!"?></h1></div>
    <div style="border: none ; box-shadow:none"><button><a href="logout.php">Logout</a></button></div>
    
</body>
</html>
