<?php  
    session_start();
	$EmpNumber=$Password='';
	$numbererr=$passwderr='';
	$flag=true;
    if(isset($_POST['login']))
	{
		$EmpNumber=$_POST['EmpNumber'];
		$Password=$_POST['Password'];

		if(empty($EmpNumber))
		{
			$numbererr="Employee Number Compulsory";
			echo $numbererr;
			$flag=false;
		}
		if(empty($Password))
		{
			$passwderr="Password Compulsory";
			echo $passwderr;
			$flag=false;
		}
	}    

    if($flag){
        $con = mysqli_connect("localhost","root","","employeedata");  
        if(mysqli_connect_errno()) {  
            die("Failed to connect with MySQL: ". mysqli_connect_error());  
        }    
            $EmpNumber = stripcslashes($EmpNumber);  
            $Password = stripcslashes($Password);  
            $EmpNumber = mysqli_real_escape_string($con, $EmpNumber);  
            $Password = mysqli_real_escape_string($con, $Password);  
          
            $sql = "select *from employee where EmpNumber = '$EmpNumber' and Password = '$Password'";  
            $result = mysqli_query($con, $sql);  
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
            $count = mysqli_num_rows($result);  
              
            if($count == 1){ 
               
               $_SESSION['EmpNumber'] = $row['EmpNumber'];
               $_SESSION['EmpName'] = $row['EmpName'];
	           $_SESSION['Password']=$row['Password'];
               //echo "<h1>Login Successful </h1>";
	           header("Location:landing.php");
    
            }  
            else{  
                echo "<h1> Login failed. Invalid username or password.</h1>";  
            }  

    }
      
?>  