<?php
//Validation 
		$nameerr=$numbererr=$departmenterr=$emailerr=$phonerr=$passerr="";
		$flag=true;
		$EmpName=$EmpNumber=$Department=$MobileNumber=$Email=$Password="";
		if(isset($_POST['submit']))
		{
			
			$EmpNumber= $_POST['EmpNumber'];
			$EmpName= $_POST['EmpName'];
			$Department = $_POST['Department'];
			$MobileNumber = $_POST['MobileNumber'];
			$Email = $_POST['Email'];
			$Password = $_POST['Password'];
			
			if(empty($EmpName))
		    {
                $nameerr="Can't be empty";
                echo $nameerr . '<br>';
                $flag=false;
		    }
            elseif(!preg_match("/^([a-zA-Z' ]+)$/",$EmpName))
            {
                $nameerr = "Name must contain only characters";
                echo $nameerr. '<br>';
                $flag= false;
            }
            if(empty($EmpNumber))
            {
                $numbererr="can't be empty";
                echo $numbererr . '<br>';
                $flag=false;
            }
            if(empty($Email))
            {
                $emailerr= "Email compulsory";
                echo $emailerr . '<br>';
                $flag=false;
            }	
            if(empty($Department))
            {
                $departmenterr= "Department compulsory";
                echo $departmenterr . '<br>';
                $flag=false;
            }	
                
            if(empty($MobileNumber))
            {
                $phonerr = "Enter mobile number";
                echo $phonerr . '<br>';
                $flag=false;
            }
            elseif(strlen($MobileNumber)!=10 || !preg_match('/^[7-9]\d{9}$/', $MobileNumber))
            {
                $phonerr = "Invalid number";
                echo $phonerr . '<br>';
                $flag=false;
            }
            if(empty($Password))
            {
                $passerr = "Password is compulsory";
                echo $passerr . '<br>';
                $flag=false;
            }
            elseif(strlen($Password)< 8)
            {
                $passerr = "Password too short";
                echo $passerr . '<br>';
                $flag=false;
            }
	
	}

if($flag == true)
{
	// Create connection
	$conn = mysqli_connect("localhost","root","","employeedata");

	// Check connection
	if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
			}
	
			$sql = "INSERT INTO employee 
			VALUES ('$EmpNumber','$EmpName','$Department','$Email','$MobileNumber','$Password')";
	
	if (mysqli_query($conn, $sql)) {
			//echo "New record created successfully.";
			header("Location: login.html");
			} 
	else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}

		mysqli_close($conn);

}

?>