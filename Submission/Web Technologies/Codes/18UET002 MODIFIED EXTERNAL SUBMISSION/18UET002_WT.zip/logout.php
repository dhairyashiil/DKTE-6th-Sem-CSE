<?php
    session_start();
    unset($_SESSION["EmpName"]);
    unset($_SESSION["EmpNumber"]);
    unset($_SESSION["Password"]);
    header("Location:login.html");
?>